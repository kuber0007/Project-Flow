import { useEffect, useState } from "react";
import { Navigate, Link, useNavigate } from "react-router-dom";

import { logoutUser } from "../services/authService";
import {
  getWorkspaces,
  getWorkspaceMembers,
} from "../services/workspaceService";
import { getWorkspaceProjects } from "../services/projectService";
import { getProjectTasks } from "../services/taskService";

function Dashboard() {
  const [user, setUser] = useState(null);
  const [workspace, setWorkspace] = useState(null);
  const [members, setMembers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const navigate = useNavigate();

  /* ================= LOAD USER ================= */

  useEffect(() => {
    document.title = "Dashboard | ProjectFlow";

    const storedUser = localStorage.getItem("user");

    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch {
        localStorage.removeItem("user");
      }
    }
  }, []);

  /* ================= FETCH DASHBOARD DATA ================= */

  useEffect(() => {
    const loadDashboard = async () => {
      try {
        setLoading(true);
        setError("");

        /* Get user's workspaces */
        const workspaceData = await getWorkspaces();

        const workspaceList = Array.isArray(workspaceData)
          ? workspaceData
          : workspaceData?.workspaces || [];

        if (!workspaceList.length) {
          setWorkspace(null);
          setProjects([]);
          setTasks([]);
          setMembers([]);
          return;
        }

        /* Use first workspace for dashboard */
        const currentWorkspace = workspaceList[0];

        setWorkspace(currentWorkspace);

        const workspaceId =
          currentWorkspace?._id || currentWorkspace?.id;

        if (!workspaceId) {
          throw new Error("Workspace ID not found");
        }

        /* Get workspace members */
        const membersData =
          await getWorkspaceMembers(workspaceId);

        setMembers(
          Array.isArray(membersData)
            ? membersData
            : membersData?.members || []
        );

        /* Get workspace projects */
        const projectData =
          await getWorkspaceProjects(workspaceId);

        const projectList = Array.isArray(projectData)
          ? projectData
          : projectData?.projects || [];

        setProjects(projectList);

        /* Get tasks from every project */
        const taskResults = await Promise.all(
          projectList.map(async (project) => {
            const projectId =
              project?._id || project?.id;

            if (!projectId) return [];

            try {
              const projectTaskData =
                await getProjectTasks(projectId);

              const projectTasks = Array.isArray(projectTaskData)
                ? projectTaskData
                : projectTaskData?.tasks || [];

              return projectTasks.map((task) => ({
                ...task,
                projectId,
                projectName:
                  project?.name || "Untitled Project",
              }));
            } catch {
              return [];
            }
          })
        );

        setTasks(taskResults.flat());
      } catch (err) {
        console.error("Dashboard loading error:", err);
        setError(
          err?.message ||
            "Unable to load dashboard data."
        );
      } finally {
        setLoading(false);
      }
    };

    if (localStorage.getItem("accessToken")) {
      loadDashboard();
    }
  }, []);

  /* ================= AUTH ================= */

  const token = localStorage.getItem("accessToken");

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  const userName = user?.name || "User";

  const handleLogout = () => {
    logoutUser();
    navigate("/login", { replace: true });
  };

  /* ================= REAL DASHBOARD STATS ================= */

  const totalProjects = projects.length;

  const completedProjects = projects.filter(
    (project) =>
      String(project?.status || "").toUpperCase() ===
      "COMPLETED"
  ).length;

  const totalTasks = tasks.length;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const overdueTasks = tasks.filter((task) => {
    if (!task?.dueDate) return false;

    const status = String(
      task?.status || ""
    ).toUpperCase();

    if (status === "DONE") return false;

    const dueDate = new Date(task.dueDate);
    dueDate.setHours(0, 0, 0, 0);

    return dueDate < today;
  });

  const todoTasks = tasks.filter(
    (task) =>
      String(task?.status || "").toUpperCase() ===
      "TODO"
  );

  /* ================= HELPERS ================= */

  const formatDate = (date) => {
    if (!date) return "No due date";

    const parsedDate = new Date(date);

    if (Number.isNaN(parsedDate.getTime())) {
      return "No due date";
    }

    return parsedDate.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const getProjectStatusClass = (status) => {
    const normalized =
      String(status || "").toUpperCase();

    if (normalized === "ACTIVE") return "active";

    if (normalized === "COMPLETED") {
      return "completed";
    }

    return "not-started";
  };

  const getProjectStatusLabel = (status) => {
    if (!status) return "NOT STARTED";

    return String(status)
      .replaceAll("_", " ")
      .toUpperCase();
  };

  const getPriorityLabel = (priority) => {
    if (!priority) return "NO PRIORITY";

    return `${String(priority)
      .replaceAll("_", " ")
      .toUpperCase()} priority`;
  };

  /* ================= LOADING ================= */

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="dashboard-loading-spinner" />
        <p>Loading your dashboard...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-page">

      {/* ================= SIDEBAR ================= */}

      <aside className="dashboard-sidebar">

        <Link
          to="/dashboard"
          className="dashboard-brand"
        >
          <span className="dashboard-brand-icon">
            ✓
          </span>

          <span>
            Project<span>Flow</span>
          </span>
        </Link>

        <nav className="dashboard-nav">

          <Link
            to="/dashboard"
            className="dashboard-nav-item active"
          >
            <span>▦</span>
            Dashboard
          </Link>

          <Link
            to="/projects"
            className="dashboard-nav-item"
          >
            <span>□</span>
            Projects
          </Link>

          <Link
            to="/team"
            className="dashboard-nav-item"
          >
            <span>♧</span>
            Team
          </Link>

          <div className="dashboard-task-link">

            <Link
              to="/tasks"
              className="dashboard-nav-item"
            >
              <span>☑</span>
              My Tasks

              {todoTasks.length > 0 && (
                <small>{todoTasks.length}</small>
              )}
            </Link>

            <span className="dashboard-arrow">
              ›
            </span>

          </div>

        </nav>


        {/* ================= REAL PROJECT LIST ================= */}

        <div className="sidebar-projects">

          <div className="sidebar-section-title">
            <span>PROJECTS</span>

            <Link to="/projects">
              →
            </Link>
          </div>

          {projects.length === 0 ? (
            <p className="sidebar-empty">
              No projects yet
            </p>
          ) : (
            projects.slice(0, 5).map((project) => {

              const projectId =
                project?._id || project?.id;

              return (
                <Link
                  key={projectId}
                  to={`/projects/${projectId}`}
                  className="sidebar-project"
                >
                  <span
                    className={`project-dot ${
                      project?.status === "COMPLETED"
                        ? "purple"
                        : "blue"
                    }`}
                  />

                  {project?.name ||
                    "Untitled Project"}
                </Link>
              );
            })
          )}

        </div>


        {/* ================= PROFILE ================= */}

        <div className="sidebar-profile-wrapper">

          <button
            type="button"
            className="sidebar-profile"
            onClick={() =>
              setShowProfileMenu(
                (prev) => !prev
              )
            }
          >

            <div className="profile-avatar">
              {userName
                .charAt(0)
                .toUpperCase()}
            </div>

            <div className="profile-info">
              <strong>{userName}</strong>

              <span>
                {workspace?.owner === user?._id
                  ? "Owner"
                  : "Member"}
              </span>
            </div>

            <span className="profile-arrow">
              {showProfileMenu
                ? "⌃"
                : "⌄"}
            </span>

          </button>


          {showProfileMenu && (
            <div className="profile-dropdown">

              <div className="profile-dropdown-user">

                <strong>
                  {userName}
                </strong>

                <span>
                  {user?.email || ""}
                </span>

              </div>

              <button
                type="button"
                className="profile-logout-button"
                onClick={handleLogout}
              >
                <span>↪</span>
                Logout
              </button>

            </div>
          )}

        </div>

      </aside>


      {/* ================= MAIN ================= */}

      <main className="dashboard-main">

        {/* ================= TOPBAR ================= */}

        <header className="dashboard-topbar">

          <div className="dashboard-search">

            <span>⌕</span>

            <input
              type="search"
              placeholder="Search projects..."
              aria-label="Search projects"
            />

          </div>


          <div className="dashboard-top-actions">

            <button
              type="button"
              className="dashboard-icon-button"
              aria-label="Toggle theme"
            >
              ☼
            </button>

            <button
              type="button"
              className="dashboard-icon-button"
              aria-label="Settings"
            >
              ⚙
            </button>

          </div>

        </header>


        {/* ================= CONTENT ================= */}

        <div className="dashboard-content-area">

          {/* ================= HEADING ================= */}

          <section className="dashboard-heading">

            <div>

              <h1>
                Welcome back, {userName}
              </h1>

              <p>
                Here's what's happening with your
                projects today.
              </p>

            </div>


            <Link
              to="/projects/new"
              className="new-project-button"
            >
              <span>+</span>
              New Project
            </Link>

          </section>


          {/* ================= ERROR ================= */}

          {error && (
            <div className="dashboard-error">
              {error}
            </div>
          )}


          {/* ================= STATS ================= */}

          <section className="dashboard-stats-grid">

            <article className="dashboard-stat-card">

              <div className="stat-card-top">

                <span>
                  Total Projects
                </span>

                <span className="stat-icon blue">
                  □
                </span>

              </div>

              <strong>
                {totalProjects}
              </strong>

              <p>
                all projects
              </p>

            </article>


            <article className="dashboard-stat-card">

              <div className="stat-card-top">

                <span>
                  Completed Projects
                </span>

                <span className="stat-icon green">
                  ✓
                </span>

              </div>

              <strong>
                {completedProjects}
              </strong>

              <p>
                of {totalProjects} total
              </p>

            </article>


            <article className="dashboard-stat-card">

              <div className="stat-card-top">

                <span>
                  Total Tasks
                </span>

                <span className="stat-icon purple">
                  ♧
                </span>

              </div>

              <strong>
                {totalTasks}
              </strong>

              <p>
                across all projects
              </p>

            </article>


            <article className="dashboard-stat-card">

              <div className="stat-card-top">

                <span>
                  Overdue Tasks
                </span>

                <span className="stat-icon orange">
                  !
                </span>

              </div>

              <strong>
                {overdueTasks.length}
              </strong>

              <p>
                need attention
              </p>

            </article>

          </section>


          {/* ================= MAIN GRID ================= */}

          <section className="dashboard-main-grid">


            {/* ================= PROJECT OVERVIEW ================= */}

            <div className="dashboard-panel project-overview-panel">

              <div className="panel-header">

                <div>

                  <h2>
                    Project Overview
                  </h2>

                  <p>
                    Track your active projects
                  </p>

                </div>

                <Link to="/projects">
                  View all →
                </Link>

              </div>


              {projects.length === 0 ? (

                <div className="dashboard-empty-state">
                  <h3>
                    No projects yet
                  </h3>

                  <p>
                    Create your first project
                    to get started.
                  </p>

                  <Link
                    to="/projects/new"
                    className="empty-state-button"
                  >
                    Create Project
                  </Link>
                </div>

              ) : (

                projects
                  .slice(0, 5)
                  .map((project) => {

                    const projectId =
                      project?._id ||
                      project?.id;

                    return (
                      <div
                        className="overview-project"
                        key={projectId}
                      >

                        <div className="overview-project-info">

                          <div className="project-title-row">

                            <div>

                              <h3>
                                {project?.name ||
                                  "Untitled Project"}
                              </h3>

                              <p>
                                {project?.description ||
                                  "No project description available."}
                              </p>

                            </div>


                            <span
                              className={`status-badge ${getProjectStatusClass(
                                project?.status
                              )}`}
                            >
                              {getProjectStatusLabel(
                                project?.status
                              )}
                            </span>

                          </div>


                          <div className="project-meta">

                            <span>
                              ◷
                            </span>

                            {project?.dueDate
                              ? formatDate(
                                  project.dueDate
                                )
                              : "No due date"}

                          </div>

                        </div>

                      </div>
                    );
                  })

              )}

            </div>


            {/* ================= TASK PANELS ================= */}

            <div className="dashboard-side-panels">


              {/* ================= TODO ================= */}

              <div className="dashboard-panel task-panel">

                <div className="panel-header compact">

                  <div className="panel-title-with-icon">

                    <span className="panel-small-icon">
                      ♧
                    </span>

                    <h2>
                      To Do
                    </h2>

                  </div>

                  <span className="task-count green-count">
                    {todoTasks.length}
                  </span>

                </div>


                {todoTasks.length === 0 ? (

                  <div className="task-empty">
                    No tasks to do 🎉
                  </div>

                ) : (

                  todoTasks
                    .slice(0, 3)
                    .map((task) => {

                      const taskId =
                        task?._id ||
                        task?.id;

                      return (
                        <div
                          className="task-card"
                          key={taskId}
                        >

                          <h3>
                            {task?.title ||
                              task?.name ||
                              "Untitled Task"}
                          </h3>

                          <div>

                            <span>
                              {getPriorityLabel(
                                task?.priority
                              )}
                            </span>

                            <span>
                              • Due:{" "}
                              {formatDate(
                                task?.dueDate
                              )}
                            </span>

                          </div>

                        </div>
                      );
                    })

                )}

              </div>


              {/* ================= OVERDUE ================= */}

              <div className="dashboard-panel task-panel">

                <div className="panel-header compact">

                  <div className="panel-title-with-icon">

                    <span className="panel-small-icon warning">
                      !
                    </span>

                    <h2>
                      Overdue
                    </h2>

                  </div>

                  <span className="task-count red-count">
                    {overdueTasks.length}
                  </span>

                </div>


                {overdueTasks.length === 0 ? (

                  <div className="task-empty">
                    No overdue tasks 🎉
                  </div>

                ) : (

                  <div className="overdue-list">

                    {overdueTasks
                      .slice(0, 5)
                      .map((task) => {

                        const taskId =
                          task?._id ||
                          task?.id;

                        return (
                          <div
                            className="task-card"
                            key={taskId}
                          >

                            <h3>
                              {task?.title ||
                                task?.name ||
                                "Untitled Task"}
                            </h3>

                            <div>

                              <span>
                                {getPriorityLabel(
                                  task?.priority
                                )}
                              </span>

                              <span>
                                • Due:{" "}
                                {formatDate(
                                  task?.dueDate
                                )}
                              </span>

                            </div>

                          </div>
                        );
                      })}

                  </div>

                )}

              </div>

            </div>

          </section>


          {/* ================= RECENT ACTIVITY ================= */}

          <section className="dashboard-panel activity-panel">

            <div className="panel-header">

              <div>

                <h2>
                  Workspace Overview
                </h2>

                <p>
                  Current information from
                  your workspace
                </p>

              </div>

            </div>


            <div className="activity-item">

              <div className="activity-icon">
                ✓
              </div>

              <div>

                <strong>
                  Workspace
                </strong>

                <p>
                  {workspace?.name ||
                    "No workspace selected"}
                </p>

              </div>

              <time>
                {members.length} members
              </time>

            </div>


            <div className="activity-item">

              <div className="activity-icon purple">
                +
              </div>

              <div>

                <strong>
                  Project progress
                </strong>

                <p>
                  {completedProjects} of{" "}
                  {totalProjects} projects
                  completed
                </p>

              </div>

              <time>
                {totalTasks} tasks
              </time>

            </div>


            <div className="activity-item">

              <div className="activity-icon">
                ✓
              </div>

              <div>

                <strong>
                  Task status
                </strong>

                <p>
                  {todoTasks.length} tasks
                  waiting to be completed
                </p>

              </div>

              <time>
                {overdueTasks.length} overdue
              </time>

            </div>

          </section>

        </div>

      </main>

    </div>
  );
}

export default Dashboard;