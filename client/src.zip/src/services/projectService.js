import apiRequest from "./api";


/* ================= CREATE PROJECT ================= */

const createProject = async (projectData) => {
  const result = await apiRequest("/projects", {
    method: "POST",
    body: JSON.stringify(projectData),
  });

  return result?.data ?? result;
};


/* ================= GET WORKSPACE PROJECTS ================= */

const getWorkspaceProjects = async (workspaceId) => {
  if (!workspaceId) {
    throw new Error("Workspace ID is required");
  }

  const result = await apiRequest(
    `/projects/workspace/${workspaceId}`
  );

  return result?.data ?? result;
};


/* ================= GET SINGLE PROJECT ================= */

const getProject = async (projectId) => {
  if (!projectId) {
    throw new Error("Project ID is required");
  }

  const result = await apiRequest(
    `/projects/${projectId}`
  );

  return result?.data ?? result;
};


/* ================= SEARCH / FILTER PROJECTS ================= */

const searchProjects = async (
  workspaceId,
  filters = {}
) => {
  if (!workspaceId) {
    throw new Error("Workspace ID is required");
  }

  const params = new URLSearchParams();

  if (filters.search) {
    params.append("search", filters.search);
  }

  if (filters.status) {
    params.append("status", filters.status);
  }

  if (filters.createdBy) {
    params.append("createdBy", filters.createdBy);
  }

  const queryString = params.toString();

  const endpoint =
    `/projects/workspace/${workspaceId}/search` +
    (queryString ? `?${queryString}` : "");

  const result = await apiRequest(endpoint);

  return result?.data ?? result;
};


/* ================= UPDATE PROJECT ================= */

const updateProject = async (
  projectId,
  projectData
) => {
  if (!projectId) {
    throw new Error("Project ID is required");
  }

  const result = await apiRequest(
    `/projects/${projectId}`,
    {
      method: "PATCH",
      body: JSON.stringify(projectData),
    }
  );

  return result?.data ?? result;
};


/* ================= DELETE PROJECT ================= */

const deleteProject = async (projectId) => {
  if (!projectId) {
    throw new Error("Project ID is required");
  }

  const result = await apiRequest(
    `/projects/${projectId}`,
    {
      method: "DELETE",
    }
  );

  return result?.data ?? result;
};


/* ================= UPDATE PROJECT MEMBERS ================= */

const updateProjectMembers = async (
  projectId,
  members
) => {
  if (!projectId) {
    throw new Error("Project ID is required");
  }

  const result = await apiRequest(
    `/projects/${projectId}/members`,
    {
      method: "PATCH",
      body: JSON.stringify({ members }),
    }
  );

  return result?.data ?? result;
};


export {
  createProject,
  getWorkspaceProjects,
  getProject,
  searchProjects,
  updateProject,
  deleteProject,
  updateProjectMembers,
};