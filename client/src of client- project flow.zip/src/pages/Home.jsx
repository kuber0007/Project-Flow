import Navbar from "../components/landing/Navbar";
import Hero from "../components/landing/Hero";
import FeatureStrip from "../components/landing/FeatureStrip";
import TeamSection from "../components/landing/TeamSection";
import PlatformSection from "../components/landing/PlatformSection";
import Footer from "../components/landing/Footer";

function Home() {
  return (
    <div className="min-h-screen overflow-hidden bg-white">
      <Navbar />

      <main>
        <Hero />

        <FeatureStrip />

        <TeamSection />

        <PlatformSection />
      </main>

      <Footer />
    </div>
  );
}

export default Home;