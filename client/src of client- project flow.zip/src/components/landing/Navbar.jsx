import { Menu, Sun } from "lucide-react";

function Navbar() {
  return (
    <header className="relative z-50 border-b border-slate-100 bg-white/90 backdrop-blur-md">
      <div className="container flex h-20 items-center justify-between">
        
        {/* Logo */}
        <a
          href="/"
          className="flex items-center gap-3"
          aria-label="ProjectFlow home"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-sm">
            <span className="text-lg font-bold">✓</span>
          </span>

          <span className="text-xl font-bold tracking-tight text-slate-900">
            Project<span className="text-indigo-500">Flow</span>
          </span>
        </a>

        {/* Desktop Navigation */}
        <nav
          className="hidden items-center gap-10 md:flex"
          aria-label="Main navigation"
        >
          <a href="#features" className="nav-link">
            Features
          </a>

          <a href="#pricing" className="nav-link">
            Pricing
          </a>

          <a href="#about" className="nav-link">
            About
          </a>

          <a href="#contact" className="nav-link">
            Contact
          </a>
        </nav>

        {/* Actions */}
        <div className="hidden items-center gap-3 md:flex">
          <button
            type="button"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-100 bg-white text-slate-600 transition hover:bg-slate-50"
            aria-label="Toggle theme"
          >
            <Sun size={18} />
          </button>

          <a
            href="/login"
            className="rounded-xl border border-slate-200 px-5 py-2.5 text-sm font-semibold text-slate-800 transition hover:border-slate-300 hover:bg-slate-50"
          >
            Login
          </a>

          <a
            href="/register"
            className="rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
          >
            Sign Up
          </a>
        </div>

        {/* Mobile Menu */}
        <button
          type="button"
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 md:hidden"
          aria-label="Open navigation menu"
        >
          <Menu size={20} />
        </button>
      </div>
    </header>
  );
}

export default Navbar;