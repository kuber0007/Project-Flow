import {
  ArrowRight,
  BarChart3,
  CheckCircle2,
  FolderKanban,
  UsersRound,
} from "lucide-react";

const benefits = [
  {
    icon: CheckCircle2,
    title: "Secure & Reliable",
    description: "Keep your project data organized and protected.",
  },
  {
    icon: BarChart3,
    title: "Fast & Efficient",
    description: "Track progress and keep your team moving forward.",
  },
  {
    icon: UsersRound,
    title: "Built for Teams",
    description: "Bring projects, tasks, and people together.",
  },
];

function PlatformSection() {
  return (
    <section className="platform-section">
      <div className="container">
        <div className="platform-card">

          {/* Left Content */}
          <div className="platform-content">
            <div className="platform-label">
              <FolderKanban size={16} />
              Everything in one place
            </div>

            <h2>
              Work smarter.
              <span> Stay organized.</span>
            </h2>

            <p>
              ProjectFlow brings your projects, tasks, and team
              collaboration together in one simple workspace.
            </p>

            <a href="/register" className="platform-button">
              Start for free
              <ArrowRight size={17} />
            </a>
          </div>

          {/* Right Benefits */}
          <div className="platform-benefits">
            {benefits.map((benefit) => {
              const Icon = benefit.icon;

              return (
                <div
                  key={benefit.title}
                  className="platform-benefit"
                >
                  <div className="platform-benefit-icon">
                    <Icon size={19} />
                  </div>

                  <div>
                    <h3>{benefit.title}</h3>

                    <p>{benefit.description}</p>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </div>
    </section>
  );
}

export default PlatformSection;