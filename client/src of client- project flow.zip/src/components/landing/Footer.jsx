import { Github, Linkedin } from "lucide-react";

function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">

        <div className="footer-divider" />

        <div className="footer-main">

          {/* Brand */}
          <a
            href="/"
            className="footer-brand"
            aria-label="ProjectFlow home"
          >
            <span className="footer-brand-icon">
              ✓
            </span>

            <span className="footer-brand-name">
              Project<span>Flow</span>
            </span>
          </a>

          {/* Right Side */}
          <div className="footer-right">

            <div className="footer-socials">
              <a
                href="#"
                aria-label="ProjectFlow on LinkedIn"
                className="footer-social"
              >
                <Linkedin size={18} />
              </a>

              <a
                href="#"
                aria-label="ProjectFlow on GitHub"
                className="footer-social"
              >
                <Github size={18} />
              </a>

              <span className="footer-made-with">
                Made with <span aria-label="love">♥</span> for teams
              </span>
            </div>

          </div>
        </div>

        {/* Bottom */}
        <div className="footer-bottom">
          <p>
            © {new Date().getFullYear()} ProjectFlow. All rights reserved.
          </p>

          <div className="footer-links">
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
          </div>
        </div>

      </div>
    </footer>
  );
}

export default Footer;