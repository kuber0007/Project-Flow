import { ArrowRight, CheckCircle2, PlayCircle } from "lucide-react";

function DashboardPreview() {
  return (
    <div className="dashboard-preview">
      <div className="dashboard-window">
        {/* Window Header */}
        <div className="dashboard-window-header">
          <div className="flex gap-1.5">
            <span className="window-dot" />
            <span className="window-dot" />
            <span className="window-dot" />
          </div>
        </div>

        <div className="dashboard-content">
          <h3>Project Overview</h3>

          {/* Stats */}
          <div className="dashboard-stats">
            <div className="mini-stat">
              <span>Total Projects</span>
              <strong>24</strong>
            </div>

            <div className="mini-stat">
              <span>Tasks Completed</span>
              <strong>68%</strong>
            </div>

            <div className="mini-stat">
              <span>Team Members</span>
              <strong>12</strong>
            </div>

            <div className="mini-stat">
              <span>On Track</span>
              <strong>89%</strong>
            </div>
          </div>

          {/* Lower Dashboard */}
          <div className="dashboard-lower">
            <div className="recent-projects">
              <h4>Recent Projects</h4>

              <div className="project-row">
                <span className="project-icon">□</span>

                <div>
                  <strong>Website Redesign</strong>
                  <small>In Progress</small>
                </div>

                <span className="progress-text">75%</span>
              </div>

              <div className="project-row">
                <span className="project-icon">□</span>

                <div>
                  <strong>Mobile App</strong>
                  <small>In Progress</small>
                </div>

                <span className="progress-text">45%</span>
              </div>

              <div className="project-row">
                <span className="project-icon orange">□</span>

                <div>
                  <strong>Marketing Campaign</strong>
                  <small>Review</small>
                </div>

                <span className="progress-text">60%</span>
              </div>
            </div>

            <div className="task-summary">
              <h4>Task Summary</h4>

              <div className="donut-chart">
                <span>128</span>
              </div>

              <div className="summary-items">
                <span>● Completed 68</span>
                <span>● In Progress 32</span>
                <span>● To Do 28</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative plant */}
      <div className="hero-plant" aria-hidden="true">
        🌿
      </div>
    </div>
  );
}

function Hero() {
  return (
    <section className="hero-section">
      <div className="hero-glow hero-glow-one" />
      <div className="hero-glow hero-glow-two" />

      <div className="container">
        <div className="grid items-center gap-14 py-20 lg:grid-cols-[0.9fr_1.1fr] lg:py-28">

          {/* Hero Text */}
          <div className="max-w-xl">
            <p className="mb-6 inline-flex items-center rounded-full border border-indigo-100 bg-indigo-50 px-4 py-2 text-sm font-medium text-indigo-600">
              Organize&nbsp; • &nbsp;Collaborate&nbsp; • &nbsp;Deliver
            </p>

            <h1 className="text-5xl font-bold leading-[1.08] tracking-tight text-slate-900 sm:text-6xl">
              Manage Projects
              <span className="mt-2 block bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 bg-clip-text text-transparent">
                Like a Pro
              </span>
            </h1>

            <p className="mt-7 max-w-lg text-lg leading-8 text-slate-500">
              A complete project management solution for teams.
              Track tasks, manage members, and deliver projects on time.
            </p>

            {/* Buttons */}
            <div className="mt-9 flex flex-wrap gap-4">
              <a
                href="/register"
                className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-500 px-6 py-3.5 font-semibold text-white shadow-md transition hover:-translate-y-0.5 hover:shadow-lg"
              >
                Get Started Free
                <ArrowRight size={18} />
              </a>

              <a
                href="#demo"
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-6 py-3.5 font-semibold text-slate-800 transition hover:border-slate-300 hover:bg-slate-50"
              >
                <PlayCircle size={18} />
                Watch Demo
              </a>
            </div>

            {/* Benefits */}
            <div className="mt-8 flex flex-wrap gap-x-7 gap-y-3">
              <div className="benefit-item">
                <CheckCircle2 size={18} />
                <span>Free forever</span>
              </div>

              <div className="benefit-item">
                <CheckCircle2 size={18} />
                <span>No credit card</span>
              </div>

              <div className="benefit-item">
                <CheckCircle2 size={18} />
                <span>Easy setup</span>
              </div>
            </div>
          </div>

          {/* Dashboard Illustration */}
          <div className="relative">
            <DashboardPreview />
          </div>
        </div>
      </div>
    </section>
  );
}

export default Hero;